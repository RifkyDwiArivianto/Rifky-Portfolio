import type { Stat } from "@/types";
import { site } from "./site";

export const stats: Stat[] = [
  { value: "3,61", label: "IPK, S1 Sistem Informasi" },
  { value: String(site.year), label: "Lulus, Universitas Darma Persada" },
];
