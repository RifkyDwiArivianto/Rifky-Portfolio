import type { Certificate } from "@/types";

export const certificates: Certificate[] = [
  {
    mark: "Udemy",
    title: "Database MySQL: Pemula Sampai Mahir",
    issuer: "Programmer Zaman Now",
    url: "https://drive.google.com/file/d/11EBWt3F87CRnf29A_0arUT2J6q0n8CNa/view?usp=drivesdk",
  },
  {
    mark: "Cisco",
    title: "Cisco IT Essentials",
    issuer: "",
    url: "https://drive.google.com/file/d/1HTAIQDajAGPA24e864rEPQlDagIUX8XF/view?usp=drivesdk",
  },
  {
    mark: "NET.",
    title: "Goes To Campus",
    issuer: "",
    url: "https://drive.google.com/file/d/1H8sck25F0dRmjcb90Z8NtWCoWw8BgYeQ/view?usp=drivesdk",
  },
];
