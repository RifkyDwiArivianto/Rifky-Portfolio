"use client";

import { useState } from "react";
import { useCases } from "@/data/usecase";
import type { ReviewStatus } from "@/types";
import { MockScreen } from "./MockScreen";
import { UseCaseDiagram } from "./UseCaseDiagram";

/** Kartu "Dari rancangan ke halaman": diagram use case yang menghidupkan layar tiruan di sebelahnya. */
export function UseCasePanel() {
  const [active, setActive] = useState(0);
  const [status, setStatus] = useState<ReviewStatus>("Menunggu");

  return (
    <aside className="dual" aria-labelledby="dual-t">
      <div className="dual-head">
        <h2 id="dual-t">Dari rancangan ke halaman</h2>
        <span className="badge">ilustrasi contoh</span>
      </div>
      <div className="dual-body">
        <div className="pane">
          <p className="pane-label">Rancang · Enterprise Architect</p>
          <UseCaseDiagram active={active} onPick={setActive} />
          <p className="hint">Klik salah satu use case untuk melihat layarnya.</p>
        </div>
        <div className="pane">
          <p className="pane-label">Bangun · Laravel, MySQL, VS Code</p>
          <div className="browser">
            <div className="bar">
              <i />
              <i />
              <i />
              <span>diagnosa.test/{useCases[active].url}</span>
            </div>
            <div className="scr" aria-live="polite">
              <MockScreen index={active} status={status} onPick={setActive} onStatusChange={setStatus} />
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
