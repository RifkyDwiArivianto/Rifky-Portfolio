import { skillGroups } from "@/data/skills";

/** Kolom kanan bagian "Pengalaman": keahlian dan alat. Tingginya mengikuti kolom garis waktu. */
export function SkillsColumn() {
  return (
    <div id="kemampuan">
      <div className="sec-head">
        <p className="eyebrow">Kemampuan</p>
        <h2>Keahlian dan alat</h2>
      </div>
      <div className="skills">
        {skillGroups.map((group) => (
          <div key={group.id} className="sk">
            <h3>{group.title}</h3>
            <ul>
              {group.items.map((item) => (
                <li
                  key={item.label}
                  className={`chip${item.learning ? " learn" : ""}`}
                  title={item.learning ? "Sedang dipelajari" : undefined}
                >
                  {item.label}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
