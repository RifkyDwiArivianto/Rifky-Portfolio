"use client";

import { useGallery } from "@/components/gallery/GalleryProvider";
import { timeline } from "@/data/timeline";

/** Kolom kiri bagian "Pengalaman": garis waktu kerja dan pendidikan. */
export function TimelineColumn() {
  const { openGallery } = useGallery();

  return (
    <div>
      <div className="sec-head">
        <p className="eyebrow">Jalur</p>
        <h2>Pengalaman dan pendidikan</h2>
      </div>
      <ol className="tl">
        {timeline.map((item) => {
          const { projectId } = item;
          return (
            <li key={item.id} data-k={item.kind}>
              <div className="tcard">
                <time>{item.period}</time>
                <div>
                  <h3>{item.title}</h3>
                  <p>{item.org}</p>
                </div>
                <div className="acts">
                  {projectId && (
                    <button className="btn sm ghost" type="button" onClick={(e) => openGallery(projectId, e.currentTarget)}>
                      Lihat proyek
                    </button>
                  )}
                  <a className="btn sm ghost" href={item.proofUrl} target="_blank" rel="noopener noreferrer">
                    Lihat dokumen ↗
                  </a>
                </div>
              </div>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
